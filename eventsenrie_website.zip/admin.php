<?php
$password = "admin123";
session_start();

if(isset($_POST['password']) && $_POST['password'] == $password){
    $_SESSION['loggedin'] = true;
}

if(!isset($_SESSION['loggedin'])){
    echo '<form method="post">
    <input type="password" name="password" placeholder="Enter admin password">
    <input type="submit" value="Login">
    </form>';
    exit;
}
?>

<h1>Admin Panel</h1>
<form method="post" enctype="multipart/form-data" action="upload.php">
    <input type="file" name="file" accept="image/*,video/*">
    <input type="submit" value="Upload">
</form>
