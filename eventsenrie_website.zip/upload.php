<?php
session_start();
if(!isset($_SESSION['loggedin'])) die("Unauthorized");

if(isset($_FILES['file'])){
    move_uploaded_file($_FILES['file']['tmp_name'], "uploads/".$_FILES['file']['name']);
    echo "Upload successful!";
}
?>
